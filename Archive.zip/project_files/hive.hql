USE default;

DROP TABLE IF EXISTS mr_visits_stats;
CREATE EXTERNAL TABLE mr_visits_stats (
    hospital_id STRING,
    year INT,
    total_patients BIGINT,
    avg_age DOUBLE,
    female_count BIGINT,
    unique_diseases STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '${hiveconf:input_dir3}';

DROP TABLE IF EXISTS hospitals_dict;
CREATE EXTERNAL TABLE hospitals_dict (
    hospital_id STRING,
    name STRING,
    city STRING,
    country STRING,
    type STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES (
    "separatorChar" = ",",
    "quoteChar"     = "\""
)
STORED AS TEXTFILE
LOCATION '${hiveconf:input_dir4}'
TBLPROPERTIES ("skip.header.line.count"="1");

DROP TABLE IF EXISTS final_hospital_stats;
CREATE EXTERNAL TABLE final_hospital_stats (
    country STRING,
    hospital_type STRING,
    total_patients BIGINT,
    avg_age DOUBLE,
    female_count BIGINT,
    unique_diseases_count BIGINT,
    patients_deviation DOUBLE
)
ROW FORMAT SERDE 'org.apache.hive.hcatalog.data.JsonSerDe'
STORED AS TEXTFILE
LOCATION '${hiveconf:output_dir6}';

WITH country_type_base AS (
    SELECT
        h.country AS country,
        h.type AS hospital_type,
        SUM(m.total_patients) AS total_patients,
        SUM(m.avg_age * m.total_patients) / SUM(m.total_patients) AS avg_age,
        SUM(m.female_count) AS female_count,
        CONCAT_WS(';', COLLECT_LIST(m.unique_diseases)) AS all_diseases_str
    FROM mr_visits_stats m
    JOIN hospitals_dict h ON m.hospital_id = h.hospital_id
    GROUP BY h.country, h.type
),
exploded_diseases AS (
    SELECT
        b.country,
        b.hospital_type,
        b.total_patients,
        b.avg_age,
        b.female_count,
        COUNT(DISTINCT CASE WHEN d.disease_code != '' THEN d.disease_code ELSE NULL END) AS unique_diseases_count
    FROM country_type_base b
    LATERAL VIEW OUTER EXPLODE(SPLIT(b.all_diseases_str, ';')) d AS disease_code
    GROUP BY
        b.country,
        b.hospital_type,
        b.total_patients,
        b.avg_age,
        b.female_count
)
INSERT OVERWRITE TABLE final_hospital_stats
SELECT
    country,
    hospital_type,
    total_patients,
    ROUND(avg_age, 4) AS avg_age,
    female_count,
    unique_diseases_count,
    ROUND(total_patients - AVG(total_patients) OVER (PARTITION BY hospital_type), 4) AS patients_deviation
FROM exploded_diseases;
