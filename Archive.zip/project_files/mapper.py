#!/usr/bin/env python3
import sys
import csv

def main():
    reader = csv.reader(sys.stdin)
    for row in reader:
        if len(row) != 8:
            continue
        
        visit_id, hospital_id, patient_name, disease, medication, date_str, age_str, gender = row
        
        if visit_id == 'visit_id' or age_str == 'age':
            continue
            
        try:
            year = date_str[:4]
            if not year.isdigit() or len(year) != 4:
                continue
                
            age = float(age_str)
            female_count = 1 if gender.strip() == 'Female' else 0
            hospital_id = hospital_id.strip()
            disease = disease.strip()
            
            if not hospital_id or not disease:
                continue
                
            print(f"{hospital_id}\t{year}\t1\t{age}\t{female_count}\t{disease}")
            
        except (ValueError, IndexError):
            continue

if __name__ == '__main__':
    main()
