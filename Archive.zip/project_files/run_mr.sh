#!/bin/bash
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <input_dir1> <output_dir3>"
    exit 1
fi

INPUT_DIR="$1"
OUTPUT_DIR="$2"

hadoop fs -rm -r -f "$OUTPUT_DIR"

mapred streaming \
    -D stream.num.map.output.key.fields=2 \
    -files mapper.py,combiner.py,reducer.py \
    -input "$INPUT_DIR" \
    -output "$OUTPUT_DIR" \
    -mapper "python3 mapper.py" \
    -combiner "python3 combiner.py" \
    -reducer "python3 reducer.py"
