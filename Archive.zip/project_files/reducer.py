#!/usr/bin/env python3
import sys

def main():
    current_key = None
    total_patients = 0
    sum_age = 0.0
    female_count = 0
    diseases_set = set()

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
            
        parts = line.split('\t')
        if len(parts) != 6:
            continue
            
        hospital_id, year, count_str, age_str, female_str, diseases_str = parts
        key = (hospital_id, year)
        
        try:
            count = int(count_str)
            age = float(age_str)
            female = int(female_str)
        except ValueError:
            continue
            
        if key == current_key:
            total_patients += count
            sum_age += age
            female_count += female
            if diseases_str:
                diseases_set.update(d for d in diseases_str.split(';') if d)
        else:
            if current_key is not None and total_patients > 0:
                avg_age = sum_age / total_patients
                diseases_joined = ';'.join(sorted(diseases_set))
                print(f"{current_key[0]}\t{current_key[1]}\t{total_patients}\t{avg_age}\t{female_count}\t{diseases_joined}")
            
            current_key = key
            total_patients = count
            sum_age = age
            female_count = female
            diseases_set = set(d for d in diseases_str.split(';') if d) if diseases_str else set()

    if current_key is not None and total_patients > 0:
        avg_age = sum_age / total_patients
        diseases_joined = ';'.join(sorted(diseases_set))
        print(f"{current_key[0]}\t{current_key[1]}\t{total_patients}\t{avg_age}\t{female_count}\t{diseases_joined}")

if __name__ == '__main__':
    main()
