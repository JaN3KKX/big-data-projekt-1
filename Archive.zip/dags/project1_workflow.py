from datetime import datetime
from airflow import DAG
from airflow.models.param import Param
from airflow.operators.bash import BashOperator
from airflow.operators.python import BranchPythonOperator

with DAG(
    dag_id="project1_workflow",
    start_date=datetime(2025, 1, 1),
    schedule=None,
    catchup=False,
    params={
        "dags_home": Param("/home/airflow/airflow/dags", type="string"),
        "input_dir": Param("/user/airflow/input", type="string"),
        "output_mr_dir": Param("/user/airflow/output_mr", type="string"),
        "output_dir": Param("/user/airflow/output", type="string"),
        "classic_or_streaming": Param("streaming", enum=["classic", "streaming"]),
    },
) as dag:

    clean_output_mr_dir = BashOperator(
        task_id="clean_output_mr_dir",
        bash_command="hadoop fs -rm -r -f {{ params.output_mr_dir }}",
    )

    clean_output_dir = BashOperator(
        task_id="clean_output_dir",
        bash_command="hadoop fs -rm -r -f {{ params.output_dir }}",
    )

    def _pick_classic_or_streaming(params):
        if params["classic_or_streaming"] == "classic":
            return "mapreduce_classic"
        return "hadoop_streaming"

    pick_classic_or_streaming = BranchPythonOperator(
        task_id="pick_classic_or_streaming",
        python_callable=_pick_classic_or_streaming,
    )

    mapreduce_classic = BashOperator(
        task_id="mapreduce_classic",
        bash_command="echo 'Wariant classic niezaimplementowany'",
    )

    hadoop_streaming = BashOperator(
        task_id="hadoop_streaming",
        bash_command=(
            "mapred streaming "
            "-D stream.num.map.output.key.fields=2 "
            "-files {{ params.dags_home }}/project_files/mapper.py,"
            "{{ params.dags_home }}/project_files/combiner.py,"
            "{{ params.dags_home }}/project_files/reducer.py "
            "-input {{ params.input_dir }}/datasource1 "
            "-output {{ params.output_mr_dir }} "
            "-mapper 'python3 mapper.py' "
            "-combiner 'python3 combiner.py' "
            "-reducer 'python3 reducer.py'"
        ),
    )

    hive = BashOperator(
        task_id="hive",
        trigger_rule="none_failed_min_one_success",
        bash_command=(
            "beeline -u jdbc:hive2://localhost:10000/default "
            "--hiveconf input_dir3={{ params.output_mr_dir }} "
            "--hiveconf input_dir4={{ params.input_dir }}/datasource4 "
            "--hiveconf output_dir6={{ params.output_dir }} "
            "-f {{ params.dags_home }}/project_files/hive.hql"
        ),
    )

    get_output = BashOperator(
        task_id="get_output",
        bash_command="hadoop fs -cat {{ params.output_dir }}/*",
    )

    [clean_output_mr_dir, clean_output_dir] >> pick_classic_or_streaming
    pick_classic_or_streaming >> [mapreduce_classic, hadoop_streaming]
    [mapreduce_classic, hadoop_streaming] >> hive >> get_output
